import { test, expect } from '@playwright/test';

const BASE_URL = process.env.TEST_URL || 'http://localhost:5000';

test.describe('Smoke Tests - Critical Paths', () => {
  test('should load the home page', async ({ page }) => {
    await page.goto(BASE_URL);
    await expect(page).toHaveTitle(/LUCREI/i);
  });

  test('should navigate to login page', async ({ page }) => {
    await page.goto(`${BASE_URL}/login`);
    await expect(page.getByRole('heading', { name: /login|entrar/i })).toBeVisible();
  });

  test('should navigate to register page', async ({ page }) => {
    await page.goto(`${BASE_URL}/register`);
    await expect(page.getByRole('heading', { name: /register|cadastr/i })).toBeVisible();
  });

  test('API health check should return 200', async ({ request }) => {
    const response = await request.get(`${BASE_URL}/api/health`);
    expect(response.ok()).toBeTruthy();
    expect(response.status()).toBe(200);
  });

  test('API liveness check should return 200', async ({ request }) => {
    const response = await request.get(`${BASE_URL}/api/liveness`);
    expect(response.ok()).toBeTruthy();
    expect(response.status()).toBe(200);
  });

  test('API readiness check should return 200', async ({ request }) => {
    const response = await request.get(`${BASE_URL}/api/readiness`);
    expect(response.ok()).toBeTruthy();
    expect(response.status()).toBe(200);
  });

  test('should show 401 for unauthenticated API access', async ({ request }) => {
    const response = await request.get(`${BASE_URL}/api/transactions`);
    expect(response.status()).toBe(401);
  });
});

test.describe('Authentication Flow', () => {
  test('should fail login with invalid credentials', async ({ page }) => {
    await page.goto(`${BASE_URL}/login`);
    
    await page.fill('input[type="email"]', 'nonexistent@test.com');
    await page.fill('input[type="password"]', 'wrongpassword');
    
    await page.click('button[type="submit"]');
    
    await expect(page.getByText(/invalid|inválid|erro/i)).toBeVisible({ timeout: 5000 });
  });
});

test.describe('Static Assets', () => {
  test('should load CSS files', async ({ page }) => {
    const response = await page.goto(BASE_URL);
    
    const stylesheets = await page.$$('link[rel="stylesheet"]');
    expect(stylesheets.length).toBeGreaterThan(0);
  });

  test('should load JavaScript files', async ({ page }) => {
    await page.goto(BASE_URL);
    
    const scripts = await page.$$('script[src]');
    expect(scripts.length).toBeGreaterThan(0);
  });
});

test.describe('Performance Checks', () => {
  test('home page should load within acceptable time', async ({ page }) => {
    const startTime = Date.now();
    await page.goto(BASE_URL);
    const loadTime = Date.now() - startTime;
    
    expect(loadTime).toBeLessThan(5000);
  });
});
