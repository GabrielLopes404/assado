import { parse as parseOFX } from "./ofx-parser";

export interface OFXTransaction {
  id: string;
  type: "debit" | "credit";
  date: Date;
  amount: number;
  description: string;
  memo?: string;
  checkNum?: string;
}

export interface MatchCandidate {
  transactionId: string;
  ofxTransactionId: string;
  confidence: number;
  reason: string;
}

export function parseOFXFile(ofxContent: string): { transactions: OFXTransaction[]; accountInfo: any } {
  const parsed = parseOFX(ofxContent);
  const transactions: OFXTransaction[] = [];

  if (parsed.body?.OFX?.BANKMSGSRSV1?.STMTTRNRS?.STMTRS?.BANKTRANLIST?.STMTTRN) {
    const stmtTrns = parsed.body.OFX.BANKMSGSRSV1.STMTTRNRS.STMTRS.BANKTRANLIST.STMTTRN;
    const trnsArray = Array.isArray(stmtTrns) ? stmtTrns : [stmtTrns];

    for (const trn of trnsArray) {
      transactions.push({
        id: trn.FITID || crypto.randomUUID(),
        type: parseFloat(trn.TRNAMT) >= 0 ? "credit" : "debit",
        date: parseOFXDate(trn.DTPOSTED),
        amount: Math.abs(parseFloat(trn.TRNAMT)),
        description: trn.NAME || trn.MEMO || "Transaction",
        memo: trn.MEMO,
        checkNum: trn.CHECKNUM,
      });
    }
  }

  const accountInfo = {
    bankId: parsed.body?.OFX?.BANKMSGSRSV1?.STMTTRNRS?.STMTRS?.BANKACCTFROM?.BANKID,
    accountId: parsed.body?.OFX?.BANKMSGSRSV1?.STMTTRNRS?.STMTRS?.BANKACCTFROM?.ACCTID,
    accountType: parsed.body?.OFX?.BANKMSGSRSV1?.STMTTRNRS?.STMTRS?.BANKACCTFROM?.ACCTTYPE,
    startDate: parseOFXDate(parsed.body?.OFX?.BANKMSGSRSV1?.STMTTRNRS?.STMTRS?.BANKTRANLIST?.DTSTART),
    endDate: parseOFXDate(parsed.body?.OFX?.BANKMSGSRSV1?.STMTTRNRS?.STMTRS?.BANKTRANLIST?.DTEND),
    currency: parsed.body?.OFX?.BANKMSGSRSV1?.STMTTRNRS?.STMTRS?.CURDEF || "BRL",
  };

  return { transactions, accountInfo };
}

function parseOFXDate(dateStr: string): Date {
  if (!dateStr) return new Date();
  const year = parseInt(dateStr.substring(0, 4));
  const month = parseInt(dateStr.substring(4, 6)) - 1;
  const day = parseInt(dateStr.substring(6, 8));
  return new Date(year, month, day);
}

export interface MatchingOptions {
  dateTolerance?: number;
  amountTolerance?: number;
  strictMatching?: boolean;
}

export function findMatches(
  ofxTransactions: OFXTransaction[],
  existingTransactions: Array<{
    id: string;
    date: Date;
    amount: number;
    description: string;
    type: "income" | "expense";
  }>,
  options: MatchingOptions = {}
): MatchCandidate[] {
  const {
    dateTolerance = 3,
    amountTolerance = 0.01,
    strictMatching = false,
  } = options;

  const matches: MatchCandidate[] = [];

  for (const ofxTrx of ofxTransactions) {
    for (const existingTrx of existingTransactions) {
      const dateMatch = isDateWithinTolerance(ofxTrx.date, existingTrx.date, dateTolerance);
      const amountMatch = isAmountMatch(ofxTrx.amount, parseFloat(existingTrx.amount.toString()), amountTolerance);
      const typeMatch = (
        (ofxTrx.type === "credit" && existingTrx.type === "income") ||
        (ofxTrx.type === "debit" && existingTrx.type === "expense")
      );

      if (dateMatch && amountMatch && typeMatch) {
        const confidence = calculateConfidence(ofxTrx, existingTrx, dateTolerance);
        matches.push({
          transactionId: existingTrx.id,
          ofxTransactionId: ofxTrx.id,
          confidence,
          reason: generateMatchReason(ofxTrx, existingTrx, confidence),
        });
      }
    }
  }

  return matches.sort((a, b) => b.confidence - a.confidence);
}

function isDateWithinTolerance(date1: Date, date2: Date, days: number): boolean {
  const diff = Math.abs(date1.getTime() - date2.getTime());
  const daysDiff = diff / (1000 * 60 * 60 * 24);
  return daysDiff <= days;
}

function isAmountMatch(amount1: number, amount2: number, tolerance: number): boolean {
  return Math.abs(amount1 - amount2) <= tolerance;
}

function calculateConfidence(ofxTrx: OFXTransaction, existingTrx: any, dateTolerance: number): number {
  let confidence = 0;

  const dateDiff = Math.abs(ofxTrx.date.getTime() - new Date(existingTrx.date).getTime()) / (1000 * 60 * 60 * 24);
  confidence += (1 - dateDiff / dateTolerance) * 50;

  const amountMatch = Math.abs(ofxTrx.amount - parseFloat(existingTrx.amount.toString())) < 0.01;
  if (amountMatch) confidence += 40;

  const descSimilarity = calculateStringSimilarity(
    ofxTrx.description.toLowerCase(),
    existingTrx.description.toLowerCase()
  );
  confidence += descSimilarity * 10;

  return Math.min(100, confidence);
}

function calculateStringSimilarity(str1: string, str2: string): number {
  const longer = str1.length > str2.length ? str1 : str2;
  const shorter = str1.length > str2.length ? str2 : str1;

  if (longer.length === 0) return 1.0;

  const editDistance = levenshteinDistance(longer, shorter);
  return (longer.length - editDistance) / longer.length;
}

function levenshteinDistance(str1: string, str2: string): number {
  const matrix: number[][] = [];

  for (let i = 0; i <= str2.length; i++) {
    matrix[i] = [i];
  }

  for (let j = 0; j <= str1.length; j++) {
    matrix[0][j] = j;
  }

  for (let i = 1; i <= str2.length; i++) {
    for (let j = 1; j <= str1.length; j++) {
      if (str2.charAt(i - 1) === str1.charAt(j - 1)) {
        matrix[i][j] = matrix[i - 1][j - 1];
      } else {
        matrix[i][j] = Math.min(
          matrix[i - 1][j - 1] + 1,
          matrix[i][j - 1] + 1,
          matrix[i - 1][j] + 1
        );
      }
    }
  }

  return matrix[str2.length][str1.length];
}

function generateMatchReason(ofxTrx: OFXTransaction, existingTrx: any, confidence: number): string {
  if (confidence >= 90) return "Correspondência exata";
  if (confidence >= 70) return "Correspondência forte";
  if (confidence >= 50) return "Correspondência provável";
  return "Correspondência fraca";
}
