import { storage } from "./storage";

export interface CashFlowPrediction {
  date: Date;
  predictedIncome: number;
  predictedExpense: number;
  predictedBalance: number;
  confidence: number;
}

export class CashFlowPredictionService {
  async predict(organizationId: string, days: 30 | 60 | 90 = 30): Promise<CashFlowPrediction[]> {
    const predictions: CashFlowPrediction[] = [];
    const today = new Date();
    
    const bankAccounts = await storage.getBankAccountsByOrganization(organizationId);
    const currentBalance = bankAccounts.reduce((sum, acc) => sum + parseFloat(acc.currentBalance), 0);

    const historicalTransactions = await this.getHistoricalTransactions(organizationId, 90);
    const recurringTransactions = await storage.getRecurringTransactionsByOrganization(organizationId);
    const pendingInvoices = await this.getPendingInvoices(organizationId);

    const dailyAverages = this.calculateDailyAverages(historicalTransactions);

    for (let i = 0; i < days; i++) {
      const predictionDate = new Date(today);
      predictionDate.setDate(predictionDate.getDate() + i + 1);

      let predictedIncome = 0;
      let predictedExpense = 0;
      let confidence = 70;

      const recurringForDate = recurringTransactions.filter(rt => 
        this.shouldOccurOnDate(rt, predictionDate)
      );
      
      for (const rt of recurringForDate) {
        if (rt.type === "income") {
          predictedIncome += parseFloat(rt.amount);
          confidence = Math.max(confidence, 95);
        } else {
          predictedExpense += parseFloat(rt.amount);
          confidence = Math.max(confidence, 95);
        }
      }

      const invoicesForDate = pendingInvoices.filter(inv => {
        const dueDate = new Date(inv.dueDate!);
        return dueDate.toDateString() === predictionDate.toDateString();
      });

      for (const inv of invoicesForDate) {
        predictedIncome += parseFloat(inv.amount);
        confidence = Math.max(confidence, 85);
      }

      if (predictedIncome === 0) {
        predictedIncome = dailyAverages.income * (1 + (Math.random() * 0.2 - 0.1));
        confidence = Math.min(confidence, 60);
      }

      if (predictedExpense === 0) {
        predictedExpense = dailyAverages.expense * (1 + (Math.random() * 0.2 - 0.1));
        confidence = Math.min(confidence, 60);
      }

      const previousBalance = i === 0 ? currentBalance : predictions[i - 1].predictedBalance;
      const predictedBalance = previousBalance + predictedIncome - predictedExpense;

      predictions.push({
        date: predictionDate,
        predictedIncome,
        predictedExpense,
        predictedBalance,
        confidence: Math.round(confidence),
      });
    }

    return predictions;
  }

  private async getHistoricalTransactions(organizationId: string, days: number) {
    const endDate = new Date();
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - days);

    return await storage.getTransactionsByDateRange(organizationId, startDate, endDate);
  }

  private async getPendingInvoices(organizationId: string) {
    const invoices = await storage.getInvoicesByOrganization(organizationId);
    return invoices.filter(inv => 
      inv.status === "pending" || inv.status === "overdue"
    );
  }

  private calculateDailyAverages(transactions: any[]): { income: number; expense: number } {
    const totalIncome = transactions
      .filter(t => t.type === "income")
      .reduce((sum, t) => sum + parseFloat(t.amount), 0);

    const totalExpense = transactions
      .filter(t => t.type === "expense")
      .reduce((sum, t) => sum + parseFloat(t.amount), 0);

    const days = 90;

    return {
      income: totalIncome / days,
      expense: totalExpense / days,
    };
  }

  private shouldOccurOnDate(recurringTransaction: any, date: Date): boolean {
    const startDate = new Date(recurringTransaction.startDate);
    if (date < startDate) return false;

    if (recurringTransaction.endDate) {
      const endDate = new Date(recurringTransaction.endDate);
      if (date > endDate) return false;
    }

    if (!recurringTransaction.active) return false;

    const daysDiff = Math.floor((date.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24));

    switch (recurringTransaction.frequency) {
      case "daily":
        return true;
      case "weekly":
        return daysDiff % 7 === 0;
      case "monthly":
        return date.getDate() === startDate.getDate();
      case "yearly":
        return date.getDate() === startDate.getDate() && date.getMonth() === startDate.getMonth();
      default:
        return false;
    }
  }
}

export const cashFlowPredictionService = new CashFlowPredictionService();
