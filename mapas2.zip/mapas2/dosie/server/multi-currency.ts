import { Router } from "express";
import { db } from "./db";
import { sql } from "drizzle-orm";

const router = Router();

function requireAuth(req: any, res: any, next: any) {
  if (!req.user) {
    return res.status(401).json({ message: "Unauthorized" });
  }
  next();
}

const EXCHANGE_RATES: { [key: string]: number } = {
  'BRL': 1.0,
  'USD': 0.20,
  'EUR': 0.18,
  'GBP': 0.16,
  'JPY': 28.50,
  'AUD': 0.30,
  'CAD': 0.27,
  'CHF': 0.17,
  'CNY': 1.44,
  'MXN': 3.42
};

async function getExchangeRate(from: string, to: string): Promise<number> {
  if (from === to) return 1.0;
  
  const fromRate = EXCHANGE_RATES[from] || 1.0;
  const toRate = EXCHANGE_RATES[to] || 1.0;
  
  return toRate / fromRate;
}

async function convertCurrency(amount: number, from: string, to: string): Promise<number> {
  const rate = await getExchangeRate(from, to);
  return amount * rate;
}

router.get("/currencies", (req, res) => {
  const currencies = [
    { code: 'BRL', name: 'Real Brasileiro', symbol: 'R$' },
    { code: 'USD', name: 'Dólar Americano', symbol: '$' },
    { code: 'EUR', name: 'Euro', symbol: '€' },
    { code: 'GBP', name: 'Libra Esterlina', symbol: '£' },
    { code: 'JPY', name: 'Iene Japonês', symbol: '¥' },
    { code: 'AUD', name: 'Dólar Australiano', symbol: 'A$' },
    { code: 'CAD', name: 'Dólar Canadense', symbol: 'C$' },
    { code: 'CHF', name: 'Franco Suíço', symbol: 'CHF' },
    { code: 'CNY', name: 'Yuan Chinês', symbol: '¥' },
    { code: 'MXN', name: 'Peso Mexicano', symbol: '$' }
  ];

  res.json(currencies);
});

router.get("/currencies/rates", async (req, res) => {
  try {
    const base = (req.query.base as string) || 'BRL';
    
    const rates: { [key: string]: number } = {};
    for (const currency of Object.keys(EXCHANGE_RATES)) {
      rates[currency] = await getExchangeRate(base, currency);
    }

    res.json({
      base,
      rates,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error("Failed to get exchange rates:", error);
    res.status(500).json({ message: "Failed to get exchange rates" });
  }
});

router.post("/currencies/convert", async (req, res) => {
  try {
    const { amount, from, to } = req.body;

    if (!amount || !from || !to) {
      return res.status(400).json({ message: "amount, from, and to are required" });
    }

    const converted = await convertCurrency(parseFloat(amount), from, to);
    const rate = await getExchangeRate(from, to);

    res.json({
      original: {
        amount: parseFloat(amount),
        currency: from
      },
      converted: {
        amount: converted,
        currency: to
      },
      rate,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error("Failed to convert currency:", error);
    res.status(500).json({ message: "Failed to convert currency" });
  }
});

router.get("/currencies/transactions", requireAuth, async (req, res) => {
  try {
    const organizationId = req.user!.organizationId;
    const currency = (req.query.currency as string) || 'BRL';

    const transactions = await db.execute(sql.raw(`
      SELECT 
        id,
        description,
        amount,
        'BRL' as original_currency,
        ${await getExchangeRate('BRL', currency)} * amount::numeric as converted_amount,
        '${currency}' as converted_currency,
        type,
        date
      FROM transactions
      WHERE organization_id = '${organizationId}'
      ORDER BY date DESC
      LIMIT 100
    `));

    res.json({
      currency,
      transactions: transactions.rows
    });
  } catch (error) {
    console.error("Failed to get transactions in currency:", error);
    res.status(500).json({ message: "Failed to get transactions" });
  }
});

export default router;
export { convertCurrency, getExchangeRate };
