import { Router } from "express";
import { db } from "./db";
import { users, organizations, invitations } from "@shared/schema";
import { eq, and, gte } from "drizzle-orm";
import bcrypt from "bcryptjs";
import crypto from "crypto";

const router = Router();

function requireAuth(req: any, res: any, next: any) {
  if (!req.user) {
    return res.status(401).json({ message: "Unauthorized" });
  }
  next();
}

function isOwnerOrAdmin(req: any, res: any, next: any) {
  if (!req.user || (req.user.role !== 'OWNER' && req.user.role !== 'ADMIN')) {
    return res.status(403).json({ message: "Forbidden: Owner or Admin access required" });
  }
  next();
}

router.post("/invitations", requireAuth, isOwnerOrAdmin, async (req, res) => {
  try {
    const { email, role } = req.body;
    const organizationId = req.user!.organizationId;

    if (!email || !role) {
      return res.status(400).json({ message: "email and role are required" });
    }

    if (!['ADMIN', 'CUSTOMER'].includes(role)) {
      return res.status(400).json({ message: "Invalid role. Must be ADMIN or CUSTOMER" });
    }

    const existingUser = await db.query.users.findFirst({
      where: eq(users.email, email)
    });

    if (existingUser && existingUser.organizationId === organizationId) {
      return res.status(400).json({ message: "User already exists in this organization" });
    }

    const token = crypto.randomBytes(32).toString('hex');
    const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);

    const [invitation] = await db.insert(invitations).values({
      organizationId,
      email,
      role,
      token,
      expiresAt
    }).returning();

    const invitationLink = `${process.env.APP_URL || 'http://localhost:5000'}/accept-invitation/${token}`;

    res.json({
      message: "Invitation created successfully",
      invitation: {
        id: invitation.id,
        email: invitation.email,
        role: invitation.role,
        expiresAt: invitation.expiresAt,
        invitationLink
      }
    });
  } catch (error) {
    console.error("Failed to create invitation:", error);
    res.status(500).json({ message: "Failed to create invitation" });
  }
});

router.get("/invitations", requireAuth, isOwnerOrAdmin, (req, res) => {
  const organizationId = req.user!.organizationId;
  
  const orgInvitations = Array.from(invitations.values())
    .filter(inv => inv.organizationId === organizationId && inv.expiresAt > new Date())
    .map(inv => ({
      id: inv.id,
      email: inv.email,
      role: inv.role,
      expiresAt: inv.expiresAt,
      createdAt: inv.createdAt
    }));

  res.json(orgInvitations);
});

router.get("/invitations/:token", async (req, res) => {
  try {
    const { token } = req.params;
    const invitation = invitations.get(token);

    if (!invitation) {
      return res.status(404).json({ message: "Invitation not found" });
    }

    if (invitation.expiresAt < new Date()) {
      invitations.delete(token);
      return res.status(400).json({ message: "Invitation has expired" });
    }

    const organization = await db.query.organizations.findFirst({
      where: eq(organizations.id, invitation.organizationId)
    });

    res.json({
      email: invitation.email,
      role: invitation.role,
      organization: {
        id: organization?.id,
        name: organization?.name
      },
      expiresAt: invitation.expiresAt
    });
  } catch (error) {
    console.error("Failed to get invitation:", error);
    res.status(500).json({ message: "Failed to get invitation" });
  }
});

router.post("/invitations/:token/accept", async (req, res) => {
  try {
    const { token } = req.params;
    const { username, password, name } = req.body;

    if (!username || !password || !name) {
      return res.status(400).json({ message: "username, password, and name are required" });
    }

    const invitation = invitations.get(token);

    if (!invitation) {
      return res.status(404).json({ message: "Invitation not found" });
    }

    if (invitation.expiresAt < new Date()) {
      invitations.delete(token);
      return res.status(400).json({ message: "Invitation has expired" });
    }

    const hashedPassword = await bcrypt.hash(password, 12);

    const newUser = await db.insert(users).values({
      organizationId: invitation.organizationId,
      username,
      email: invitation.email,
      password: hashedPassword,
      name,
      role: invitation.role as any,
      emailVerified: true
    }).returning();

    invitations.delete(token);

    res.json({
      message: "Invitation accepted successfully",
      user: {
        id: newUser[0].id,
        email: newUser[0].email,
        name: newUser[0].name,
        role: newUser[0].role
      }
    });
  } catch (error) {
    console.error("Failed to accept invitation:", error);
    res.status(500).json({ message: "Failed to accept invitation" });
  }
});

router.delete("/invitations/:id", requireAuth, isOwnerOrAdmin, (req, res) => {
  const { id } = req.params;
  const organizationId = req.user!.organizationId;

  let deleted = false;
  for (const [token, invitation] of Array.from(invitations.entries())) {
    if (invitation.id === id && invitation.organizationId === organizationId) {
      invitations.delete(token);
      deleted = true;
      break;
    }
  }

  if (!deleted) {
    return res.status(404).json({ message: "Invitation not found" });
  }

  res.json({ message: "Invitation deleted successfully" });
});

router.get("/organization/members", requireAuth, async (req, res) => {
  try {
    const organizationId = req.user!.organizationId;

    if (!organizationId) {
      return res.status(400).json({ message: "Organization ID required" });
    }

    const members = await db.query.users.findMany({
      where: eq(users.organizationId, organizationId),
      columns: {
        id: true,
        username: true,
        email: true,
        name: true,
        role: true,
        emailVerified: true,
        createdAt: true
      }
    });

    res.json(members);
  } catch (error) {
    console.error("Failed to get members:", error);
    res.status(500).json({ message: "Failed to get organization members" });
  }
});

router.put("/organization/members/:id/role", requireAuth, isOwnerOrAdmin, async (req, res) => {
  try {
    const { id } = req.params;
    const { role } = req.body;
    const organizationId = req.user!.organizationId;

    if (!organizationId) {
      return res.status(400).json({ message: "Organization ID required" });
    }

    if (!['ADMIN', 'CUSTOMER'].includes(role)) {
      return res.status(400).json({ message: "Invalid role" });
    }

    const member = await db.query.users.findFirst({
      where: eq(users.id, id)
    });

    if (!member || member.organizationId !== organizationId) {
      return res.status(404).json({ message: "Member not found" });
    }

    if (member.role === 'OWNER') {
      return res.status(400).json({ message: "Cannot change role of organization owner" });
    }

    await db.update(users)
      .set({ role: role as any })
      .where(eq(users.id, id));

    res.json({ message: "Member role updated successfully" });
  } catch (error) {
    console.error("Failed to update member role:", error);
    res.status(500).json({ message: "Failed to update member role" });
  }
});

router.delete("/organization/members/:id", requireAuth, isOwnerOrAdmin, async (req, res) => {
  try {
    const { id } = req.params;
    const organizationId = req.user!.organizationId;

    if (!organizationId) {
      return res.status(400).json({ message: "Organization ID required" });
    }

    const member = await db.query.users.findFirst({
      where: eq(users.id, id)
    });

    if (!member || member.organizationId !== organizationId) {
      return res.status(404).json({ message: "Member not found" });
    }

    if (member.role === 'OWNER') {
      return res.status(400).json({ message: "Cannot remove organization owner" });
    }

    await db.delete(users).where(eq(users.id, id));

    res.json({ message: "Member removed successfully" });
  } catch (error) {
    console.error("Failed to remove member:", error);
    res.status(500).json({ message: "Failed to remove member" });
  }
});

export default router;
