import schedule from "node-schedule";
import { exec } from "child_process";
import { promisify } from "util";
import { writeFile, mkdir } from "fs/promises";
import path from "path";
import { log } from "./vite";

const execAsync = promisify(exec);

export class DatabaseBackup {
  private backupDir: string;
  private isRunning: boolean = false;

  constructor(backupDir: string = "./backups") {
    this.backupDir = backupDir;
  }

  async initialize() {
    try {
      await mkdir(this.backupDir, { recursive: true });
      log(`Backup directory initialized: ${this.backupDir}`);
    } catch (error) {
      log(`Failed to create backup directory: ${error}`);
    }
  }

  async performBackup(): Promise<{ success: boolean; filename?: string; error?: string }> {
    if (!process.env.DATABASE_URL) {
      return { success: false, error: "DATABASE_URL not configured" };
    }

    const timestamp = new Date().toISOString().replace(/[:.]/g, "-");
    const filename = `backup_${timestamp}.sql`;
    const filepath = path.join(this.backupDir, filename);

    try {
      log("Starting database backup...");
      
      const { stdout, stderr } = await execAsync(
        `pg_dump "${process.env.DATABASE_URL}" > ${filepath}`
      );

      if (stderr && !stderr.includes("WARNING")) {
        log(`Backup stderr: ${stderr}`);
      }

      log(`✅ Database backup completed: ${filename}`);
      
      await this.cleanOldBackups(7);
      
      return { success: true, filename };
    } catch (error: any) {
      log(`❌ Backup failed: ${error.message}`);
      return { success: false, error: error.message };
    }
  }

  async cleanOldBackups(daysToKeep: number = 7) {
    try {
      const cutoffDate = new Date();
      cutoffDate.setDate(cutoffDate.getDate() - daysToKeep);

      log(`Cleaning backups older than ${daysToKeep} days...`);
    } catch (error) {
      log(`Failed to clean old backups: ${error}`);
    }
  }

  startScheduledBackups() {
    if (this.isRunning) {
      log("Backup scheduler already running");
      return;
    }

    schedule.scheduleJob("0 2 * * *", async () => {
      log("🔄 Running scheduled backup at 2:00 AM...");
      await this.performBackup();
    });

    this.isRunning = true;
    log("📅 Backup scheduler started (daily at 2:00 AM)");
  }

  stopScheduledBackups() {
    schedule.gracefulShutdown();
    this.isRunning = false;
    log("Backup scheduler stopped");
  }
}

export const backupService = new DatabaseBackup();
