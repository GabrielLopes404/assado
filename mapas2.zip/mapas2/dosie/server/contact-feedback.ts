import { Router } from "express";
import { z } from "zod";
import { sendEmail } from "./email";

const router = Router();

const contactSchema = z.object({
  name: z.string().min(2, "Nome deve ter pelo menos 2 caracteres"),
  email: z.string().email("Email inválido"),
  subject: z.string().min(5, "Assunto deve ter pelo menos 5 caracteres"),
  message: z.string().min(10, "Mensagem deve ter pelo menos 10 caracteres"),
  phone: z.string().optional()
});

const feedbackSchema = z.object({
  type: z.enum(["bug", "feature", "improvement", "other"]),
  title: z.string().min(3, "Título deve ter pelo menos 3 caracteres"),
  description: z.string().min(10, "Descrição deve ter pelo menos 10 caracteres"),
  priority: z.enum(["low", "medium", "high"]).optional(),
  email: z.string().email("Email inválido").optional()
});

router.post("/contact", async (req, res) => {
  try {
    const validatedData = contactSchema.parse(req.body);

    await sendEmail({
      to: process.env.SUPPORT_EMAIL || "support@lucrei.com",
      subject: `[Contato] ${validatedData.subject}`,
      html: `
        <h2>Nova mensagem de contato</h2>
        <p><strong>Nome:</strong> ${validatedData.name}</p>
        <p><strong>Email:</strong> ${validatedData.email}</p>
        ${validatedData.phone ? `<p><strong>Telefone:</strong> ${validatedData.phone}</p>` : ''}
        <p><strong>Assunto:</strong> ${validatedData.subject}</p>
        <p><strong>Mensagem:</strong></p>
        <p>${validatedData.message}</p>
      `,
      text: `
        Nova mensagem de contato
        Nome: ${validatedData.name}
        Email: ${validatedData.email}
        ${validatedData.phone ? `Telefone: ${validatedData.phone}` : ''}
        Assunto: ${validatedData.subject}
        Mensagem: ${validatedData.message}
      `
    });

    await sendEmail({
      to: validatedData.email,
      subject: "Recebemos sua mensagem - LUCREI",
      html: `
        <h2>Olá ${validatedData.name}!</h2>
        <p>Recebemos sua mensagem e entraremos em contato em breve.</p>
        <p><strong>Assunto:</strong> ${validatedData.subject}</p>
        <p>Nossa equipe responderá o mais rápido possível.</p>
        <br>
        <p>Obrigado por entrar em contato com o LUCREI!</p>
      `,
      text: `
        Olá ${validatedData.name}!
        Recebemos sua mensagem e entraremos em contato em breve.
        Assunto: ${validatedData.subject}
        Nossa equipe responderá o mais rápido possível.
        Obrigado por entrar em contato com o LUCREI!
      `
    });

    res.json({ 
      success: true, 
      message: "Mensagem enviada com sucesso! Entraremos em contato em breve." 
    });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ 
        message: "Dados inválidos", 
        errors: error.errors 
      });
    }
    console.error("Contact form error:", error);
    res.status(500).json({ message: "Erro ao enviar mensagem" });
  }
});

router.post("/feedback", async (req, res) => {
  try {
    const userId = req.user?.id;
    const userEmail = req.user?.email || req.body.email;

    const validatedData = feedbackSchema.parse(req.body);

    const typeLabels = {
      bug: "🐛 Bug Report",
      feature: "✨ Feature Request",
      improvement: "🚀 Improvement",
      other: "💬 Other"
    };

    const priorityEmoji = {
      low: "🟢",
      medium: "🟡",
      high: "🔴"
    };

    await sendEmail({
      to: process.env.SUPPORT_EMAIL || "support@lucrei.com",
      subject: `[Feedback] ${typeLabels[validatedData.type]} - ${validatedData.title}`,
      html: `
        <h2>${typeLabels[validatedData.type]}</h2>
        ${validatedData.priority ? `<p>${priorityEmoji[validatedData.priority]} <strong>Prioridade:</strong> ${validatedData.priority.toUpperCase()}</p>` : ''}
        <p><strong>Título:</strong> ${validatedData.title}</p>
        <p><strong>Descrição:</strong></p>
        <p>${validatedData.description}</p>
        ${userId ? `<p><strong>User ID:</strong> ${userId}</p>` : ''}
        ${userEmail ? `<p><strong>Email:</strong> ${userEmail}</p>` : ''}
        <hr>
        <p><small>Enviado via formulário de feedback do LUCREI</small></p>
      `,
      text: `
        ${typeLabels[validatedData.type]}
        ${validatedData.priority ? `Prioridade: ${validatedData.priority.toUpperCase()}` : ''}
        Título: ${validatedData.title}
        Descrição: ${validatedData.description}
        ${userId ? `User ID: ${userId}` : ''}
        ${userEmail ? `Email: ${userEmail}` : ''}
      `
    });

    if (userEmail) {
      await sendEmail({
        to: userEmail,
        subject: "Recebemos seu feedback - LUCREI",
        html: `
          <h2>Obrigado pelo feedback!</h2>
          <p>Recebemos sua contribuição sobre:</p>
          <p><strong>${validatedData.title}</strong></p>
          <p>Sua opinião é muito importante para melhorarmos o LUCREI!</p>
          <br>
          <p>Equipe LUCREI</p>
        `,
        text: `
          Obrigado pelo feedback!
          Recebemos sua contribuição sobre: ${validatedData.title}
          Sua opinião é muito importante para melhorarmos o LUCREI!
          Equipe LUCREI
        `
      });
    }

    res.json({ 
      success: true, 
      message: "Feedback enviado com sucesso! Obrigado pela contribuição." 
    });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ 
        message: "Dados inválidos", 
        errors: error.errors 
      });
    }
    console.error("Feedback error:", error);
    res.status(500).json({ message: "Erro ao enviar feedback" });
  }
});

export default router;
