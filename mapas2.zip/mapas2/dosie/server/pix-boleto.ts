import QRCode from "qrcode";
import crypto from "crypto";

export interface PIXPayload {
  pixKey: string;
  merchantName: string;
  merchantCity: string;
  amount: number;
  txId?: string;
  description?: string;
}

export interface BoletoData {
  amount: number;
  dueDate: Date;
  customerName: string;
  customerDocument: string;
  description: string;
  ourNumber: string;
  documentNumber: string;
}

export class PIXService {
  static async generateQRCode(payload: PIXPayload): Promise<{ qrCode: string; brCode: string }> {
    const brCode = this.generateBRCode(payload);
    const qrCode = await QRCode.toDataURL(brCode);
    
    return { qrCode, brCode };
  }

  static generateBRCode(payload: PIXPayload): string {
    const { pixKey, merchantName, merchantCity, amount, txId, description } = payload;

    const txIdValue = txId || crypto.randomBytes(16).toString("hex").substring(0, 25);
    
    const merchantAccountInfo = this.generateEMVField("00", pixKey);
    const merchantCategoryCode = this.generateEMVField("01", "0000");
    const transactionCurrency = this.generateEMVField("02", "986");
    const transactionAmount = this.generateEMVField("03", amount.toFixed(2));
    const countryCode = this.generateEMVField("04", "BR");
    const merchantNameField = this.generateEMVField("05", merchantName.substring(0, 25));
    const merchantCityField = this.generateEMVField("06", merchantCity.substring(0, 15));
    const txIdField = this.generateEMVField("07", txIdValue);
    const descriptionField = description ? this.generateEMVField("08", description.substring(0, 72)) : "";

    const payload = 
      "000201" +
      "26" + this.generateEMVField("01", merchantAccountInfo) +
      "52" + merchantCategoryCode +
      "53" + transactionCurrency +
      "54" + transactionAmount +
      "58" + countryCode +
      "59" + merchantNameField +
      "60" + merchantCityField +
      "62" + (txIdField + descriptionField) +
      "6304";

    const crc = this.calculateCRC16(payload);
    return payload + crc;
  }

  private static generateEMVField(id: string, value: string): string {
    const length = value.length.toString().padStart(2, "0");
    return id + length + value;
  }

  private static calculateCRC16(payload: string): string {
    const polynomial = 0x1021;
    let crc = 0xFFFF;

    for (let i = 0; i < payload.length; i++) {
      crc ^= payload.charCodeAt(i) << 8;
      for (let j = 0; j < 8; j++) {
        if ((crc & 0x8000) !== 0) {
          crc = (crc << 1) ^ polynomial;
        } else {
          crc = crc << 1;
        }
      }
    }

    crc = crc & 0xFFFF;
    return crc.toString(16).toUpperCase().padStart(4, "0");
  }
}

export class BoletoService {
  static generateBoletoNumber(bankCode: string, ourNumber: string): string {
    const bankCodePart = bankCode.padStart(3, "0");
    const currencyCode = "9";
    const ourNumberPart = ourNumber.padStart(10, "0");
    
    const digitableLine = `${bankCodePart}${currencyCode}${ourNumberPart}`;
    const checkDigit = this.calculateBoletoCheckDigit(digitableLine);
    
    return `${digitableLine}${checkDigit}`;
  }

  private static calculateBoletoCheckDigit(value: string): string {
    const digits = value.split("").map(Number);
    let sum = 0;
    let multiplier = 2;

    for (let i = digits.length - 1; i >= 0; i--) {
      let product = digits[i] * multiplier;
      if (product > 9) product = product - 9;
      sum += product;
      multiplier = multiplier === 2 ? 1 : 2;
    }

    const remainder = sum % 10;
    return remainder === 0 ? "0" : (10 - remainder).toString();
  }

  static generateBarcode(boletoNumber: string): string {
    return boletoNumber.replace(/[^0-9]/g, "");
  }

  static formatBoletoLine(boletoNumber: string): string {
    const cleaned = boletoNumber.replace(/[^0-9]/g, "");
    
    if (cleaned.length !== 47) {
      throw new Error("Boleto number must have 47 digits");
    }

    return `${cleaned.substring(0, 5)}.${cleaned.substring(5, 10)} ` +
           `${cleaned.substring(10, 15)}.${cleaned.substring(15, 21)} ` +
           `${cleaned.substring(21, 26)}.${cleaned.substring(26, 32)} ` +
           `${cleaned.substring(32, 33)} ${cleaned.substring(33, 47)}`;
  }

  static async generateBoletoPDF(data: BoletoData): Promise<Buffer> {
    const PDFDocument = require("pdfkit");
    const doc = new PDFDocument({ size: "A4", margin: 50 });
    
    const chunks: Buffer[] = [];
    doc.on("data", (chunk: Buffer) => chunks.push(chunk));
    
    return new Promise((resolve) => {
      doc.on("end", () => resolve(Buffer.concat(chunks)));

      doc.fontSize(20).text("BOLETO BANCÁRIO", { align: "center" });
      doc.moveDown();

      doc.fontSize(12);
      doc.text(`Beneficiário: LUCREI - Sistema de Gestão Financeira`);
      doc.text(`Pagador: ${data.customerName}`);
      doc.text(`CPF/CNPJ: ${data.customerDocument}`);
      doc.text(`Vencimento: ${data.dueDate.toLocaleDateString("pt-BR")}`);
      doc.text(`Valor: R$ ${data.amount.toFixed(2)}`);
      doc.text(`Nosso Número: ${data.ourNumber}`);
      doc.text(`Número do Documento: ${data.documentNumber}`);
      doc.moveDown();
      doc.text(`Descrição: ${data.description}`);
      
      doc.moveDown(2);
      doc.fontSize(10);
      doc.text("INSTRUÇÕES:", { underline: true });
      doc.text("- Não receber após o vencimento");
      doc.text("- Em caso de dúvidas, entre em contato");

      doc.end();
    });
  }
}
