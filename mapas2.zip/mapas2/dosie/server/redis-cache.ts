import { Router } from "express";

const router = Router();

class RedisCache {
  private cache: Map<string, { value: any; expiry: number }> = new Map();

  async get<T>(key: string): Promise<T | null> {
    const item = this.cache.get(key);
    if (!item) return null;

    if (Date.now() > item.expiry) {
      this.cache.delete(key);
      return null;
    }

    return item.value as T;
  }

  async set(key: string, value: any, ttlSeconds: number = 300): Promise<void> {
    this.cache.set(key, {
      value,
      expiry: Date.now() + (ttlSeconds * 1000)
    });
  }

  async del(key: string): Promise<void> {
    this.cache.delete(key);
  }

  async flush(): Promise<void> {
    this.cache.clear();
  }

  async keys(pattern: string): Promise<string[]> {
    const regex = new RegExp(pattern.replace('*', '.*'));
    return Array.from(this.cache.keys()).filter(key => regex.test(key));
  }

  async invalidatePattern(pattern: string): Promise<void> {
    const keys = await this.keys(pattern);
    for (const key of keys) {
      this.cache.delete(key);
    }
  }
}

export const redisCache = new RedisCache();

export function cacheMiddleware(keyPrefix: string, ttl: number = 300) {
  return async (req: any, res: any, next: any) => {
    const cacheKey = `${keyPrefix}:${req.user?.organizationId || 'public'}:${JSON.stringify(req.query)}`;
    
    const cached = await redisCache.get(cacheKey);
    if (cached) {
      return res.json(cached);
    }

    const originalJson = res.json.bind(res);
    res.json = function(body: any) {
      redisCache.set(cacheKey, body, ttl);
      return originalJson(body);
    };

    next();
  };
}

function requireAuth(req: any, res: any, next: any) {
  if (!req.user) {
    return res.status(401).json({ message: "Unauthorized" });
  }
  next();
}

function isOwnerOrAdmin(req: any, res: any, next: any) {
  if (!req.user || (req.user.role !== 'OWNER' && req.user.role !== 'ADMIN')) {
    return res.status(403).json({ message: "Forbidden: Owner or Admin access required" });
  }
  next();
}

router.post("/cache/flush", requireAuth, isOwnerOrAdmin, async (req, res) => {
  try {
    await redisCache.flush();
    
    const { logAuditTrail } = await import("./audit-trail");
    await logAuditTrail({
      organizationId: req.user!.organizationId || undefined,
      userId: req.user!.id,
      action: 'cache_flushed',
      ipAddress: req.ip || req.socket.remoteAddress || undefined,
      userAgent: req.headers['user-agent'] || undefined
    });

    res.json({ message: "Cache flushed successfully" });
  } catch (error) {
    console.error("Failed to flush cache:", error);
    res.status(500).json({ message: "Failed to flush cache" });
  }
});

router.post("/cache/invalidate", requireAuth, isOwnerOrAdmin, async (req, res) => {
  try {
    const { pattern } = req.body;
    if (!pattern) {
      return res.status(400).json({ message: "Pattern is required" });
    }

    await redisCache.invalidatePattern(pattern);

    const { logAuditTrail } = await import("./audit-trail");
    await logAuditTrail({
      organizationId: req.user!.organizationId || undefined,
      userId: req.user!.id,
      action: 'cache_invalidated',
      metadata: { pattern },
      ipAddress: req.ip || req.socket.remoteAddress || undefined,
      userAgent: req.headers['user-agent'] || undefined
    });

    res.json({ message: `Cache invalidated for pattern: ${pattern}` });
  } catch (error) {
    console.error("Failed to invalidate cache:", error);
    res.status(500).json({ message: "Failed to invalidate cache" });
  }
});

router.get("/cache/stats", requireAuth, isOwnerOrAdmin, async (req, res) => {
  try {
    const allKeys = await redisCache.keys('*');
    res.json({
      totalKeys: allKeys.length,
      keys: allKeys
    });
  } catch (error) {
    console.error("Failed to get cache stats:", error);
    res.status(500).json({ message: "Failed to get cache stats" });
  }
});

export default router;
