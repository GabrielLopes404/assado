import { Router } from "express";
import { db } from "./db";
import { sql } from "drizzle-orm";

const router = Router();

function requireAuth(req: any, res: any, next: any) {
  if (!req.user) {
    return res.status(401).json({ message: "Unauthorized" });
  }
  next();
}

function isOwner(req: any, res: any, next: any) {
  if (!req.user || req.user.role !== 'OWNER') {
    return res.status(403).json({ message: "Forbidden: Owner access required" });
  }
  next();
}

const ALLOWED_TABLES = ['transactions', 'invoices', 'customers', 'categories', 'bank_accounts', 'cost_centers', 'tags', 'documents'];

router.post("/performance/analyze-query", requireAuth, isOwner, async (req, res) => {
  try {
    const { table, limit } = req.body;

    if (!table || !ALLOWED_TABLES.includes(table)) {
      return res.status(400).json({ 
        message: "Invalid table. Allowed tables: " + ALLOWED_TABLES.join(', ')
      });
    }

    const safeLimit = Math.min(parseInt(limit) || 100, 1000);
    const safeQuery = `SELECT * FROM ${table} LIMIT ${safeLimit}`;

    const explainResult = await db.execute(sql.raw(`EXPLAIN ANALYZE ${safeQuery}`));

    res.json({
      table,
      limit: safeLimit,
      analysis: explainResult.rows,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error("Query analysis error:", error);
    res.status(500).json({ message: "Failed to analyze query" });
  }
});

router.get("/performance/slow-queries", requireAuth, isOwner, async (req, res) => {
  try {
    const slowQueries = await db.execute(sql.raw(`
      SELECT 
        query,
        calls,
        total_exec_time,
        mean_exec_time,
        max_exec_time
      FROM pg_stat_statements
      WHERE mean_exec_time > 100
      ORDER BY mean_exec_time DESC
      LIMIT 20
    `));

    res.json(slowQueries.rows);
  } catch (error) {
    console.error("Failed to get slow queries:", error);
    res.status(500).json({ message: "Extension pg_stat_statements may not be enabled" });
  }
});

router.get("/performance/database-stats", requireAuth, isOwner, async (req, res) => {
  try {
    const stats = await db.execute(sql.raw(`
      SELECT 
        schemaname,
        tablename,
        pg_size_pretty(pg_total_relation_size(schemaname||'.'||tablename)) AS size,
        n_tup_ins AS inserts,
        n_tup_upd AS updates,
        n_tup_del AS deletes,
        n_live_tup AS live_tuples,
        n_dead_tup AS dead_tuples,
        last_vacuum,
        last_autovacuum,
        last_analyze,
        last_autoanalyze
      FROM pg_stat_user_tables
      ORDER BY pg_total_relation_size(schemaname||'.'||tablename) DESC
      LIMIT 20
    `));

    res.json(stats.rows);
  } catch (error) {
    console.error("Failed to get database stats:", error);
    res.status(500).json({ message: "Failed to get database stats" });
  }
});

router.get("/performance/index-usage", requireAuth, isOwner, async (req, res) => {
  try {
    const indexUsage = await db.execute(sql.raw(`
      SELECT 
        schemaname,
        tablename,
        indexname,
        idx_scan,
        idx_tup_read,
        idx_tup_fetch,
        pg_size_pretty(pg_relation_size(indexrelid)) AS index_size
      FROM pg_stat_user_indexes
      ORDER BY idx_scan ASC, pg_relation_size(indexrelid) DESC
      LIMIT 20
    `));

    res.json(indexUsage.rows);
  } catch (error) {
    console.error("Failed to get index usage:", error);
    res.status(500).json({ message: "Failed to get index usage" });
  }
});

router.post("/performance/create-index", requireAuth, isOwner, async (req, res) => {
  try {
    const { table, column, indexName } = req.body;

    if (!table || !column || !indexName) {
      return res.status(400).json({ message: "table, column, and indexName are required" });
    }

    if (!ALLOWED_TABLES.includes(table)) {
      return res.status(400).json({ 
        message: "Invalid table. Allowed tables: " + ALLOWED_TABLES.join(', ')
      });
    }

    const safeIndexName = indexName.replace(/[^a-zA-Z0-9_]/g, '');
    const safeColumn = column.replace(/[^a-zA-Z0-9_]/g, '');

    await db.execute(sql.raw(`
      CREATE INDEX CONCURRENTLY IF NOT EXISTS ${safeIndexName}
      ON ${table} (${safeColumn})
    `));

    res.json({ message: `Index ${safeIndexName} created successfully` });
  } catch (error) {
    console.error("Failed to create index:", error);
    res.status(500).json({ message: "Failed to create index" });
  }
});

export default router;
