import { storage } from "./storage";
import XLSX from "xlsx";

export interface AgingReportEntry {
  customerId: string;
  customerName: string;
  current: number;
  days1to30: number;
  days31to60: number;
  days61to90: number;
  over90: number;
  total: number;
}

export interface PeriodComparison {
  metric: string;
  period1Value: number;
  period2Value: number;
  difference: number;
  percentageChange: number;
}

export class AdvancedReportsService {
  async generateAgingReport(
    organizationId: string,
    type: "receivable" | "payable"
  ): Promise<AgingReportEntry[]> {
    const invoices = await storage.getInvoicesByOrganization(organizationId);
    const today = new Date();

    const agingMap = new Map<string, AgingReportEntry>();

    for (const invoice of invoices) {
      if (invoice.status === "paid" || invoice.status === "canceled") {
        continue;
      }

      const customer = await storage.getCustomer(invoice.customerId);
      if (!customer) continue;

      if (!agingMap.has(customer.id)) {
        agingMap.set(customer.id, {
          customerId: customer.id,
          customerName: customer.name,
          current: 0,
          days1to30: 0,
          days31to60: 0,
          days61to90: 0,
          over90: 0,
          total: 0,
        });
      }

      const entry = agingMap.get(customer.id)!;
      const amount = parseFloat(invoice.amount);
      const dueDate = new Date(invoice.dueDate!);
      const daysOverdue = Math.floor((today.getTime() - dueDate.getTime()) / (1000 * 60 * 60 * 24));

      if (daysOverdue <= 0) {
        entry.current += amount;
      } else if (daysOverdue <= 30) {
        entry.days1to30 += amount;
      } else if (daysOverdue <= 60) {
        entry.days31to60 += amount;
      } else if (daysOverdue <= 90) {
        entry.days61to90 += amount;
      } else {
        entry.over90 += amount;
      }

      entry.total += amount;
    }

    return Array.from(agingMap.values()).sort((a, b) => b.total - a.total);
  }

  async comparePeriods(
    organizationId: string,
    period1Start: Date,
    period1End: Date,
    period2Start: Date,
    period2End: Date
  ): Promise<PeriodComparison[]> {
    const period1Transactions = await storage.getTransactionsByDateRange(
      organizationId,
      period1Start,
      period1End
    );

    const period2Transactions = await storage.getTransactionsByDateRange(
      organizationId,
      period2Start,
      period2End
    );

    const calculateMetrics = (transactions: any[]) => {
      const income = transactions
        .filter(t => t.type === "income")
        .reduce((sum, t) => sum + parseFloat(t.amount), 0);

      const expense = transactions
        .filter(t => t.type === "expense")
        .reduce((sum, t) => sum + parseFloat(t.amount), 0);

      return {
        income,
        expense,
        profit: income - expense,
        transactionCount: transactions.length,
      };
    };

    const period1Metrics = calculateMetrics(period1Transactions);
    const period2Metrics = calculateMetrics(period2Transactions);

    const createComparison = (metric: string, p1: number, p2: number): PeriodComparison => ({
      metric,
      period1Value: p1,
      period2Value: p2,
      difference: p1 - p2,
      percentageChange: p2 === 0 ? 0 : ((p1 - p2) / p2) * 100,
    });

    return [
      createComparison("Receitas", period1Metrics.income, period2Metrics.income),
      createComparison("Despesas", period1Metrics.expense, period2Metrics.expense),
      createComparison("Lucro", period1Metrics.profit, period2Metrics.profit),
      createComparison("Transações", period1Metrics.transactionCount, period2Metrics.transactionCount),
    ];
  }

  async exportToExcelWithFormulas(
    organizationId: string,
    startDate: Date,
    endDate: Date
  ): Promise<Buffer> {
    const transactions = await storage.getTransactionsByDateRange(organizationId, startDate, endDate);

    const workbook = XLSX.utils.book_new();

    const transactionsData = transactions.map((t, index) => ({
      Data: new Date(t.date).toLocaleDateString("pt-BR"),
      Descrição: t.description,
      Tipo: t.type === "income" ? "Receita" : "Despesa",
      Valor: parseFloat(t.amount),
      Categoria: t.categoryId || "N/A",
    }));

    const worksheet = XLSX.utils.json_to_sheet(transactionsData);

    const lastRow = transactionsData.length + 2;
    worksheet[`A${lastRow}`] = { t: "s", v: "TOTAL RECEITAS:" };
    worksheet[`D${lastRow}`] = { 
      t: "n", 
      f: `SUMIF(C2:C${lastRow - 1},"Receita",D2:D${lastRow - 1})` 
    };

    worksheet[`A${lastRow + 1}`] = { t: "s", v: "TOTAL DESPESAS:" };
    worksheet[`D${lastRow + 1}`] = { 
      t: "n", 
      f: `SUMIF(C2:C${lastRow - 1},"Despesa",D2:D${lastRow - 1})` 
    };

    worksheet[`A${lastRow + 2}`] = { t: "s", v: "SALDO:" };
    worksheet[`D${lastRow + 2}`] = { 
      t: "n", 
      f: `D${lastRow}-D${lastRow + 1}` 
    };

    worksheet["!ref"] = `A1:D${lastRow + 2}`;

    XLSX.utils.book_append_sheet(workbook, worksheet, "Transações");

    const summaryData = [
      { Métrica: "Total de Transações", Valor: transactionsData.length },
      { Métrica: "Receitas", Valor: { f: `Transações!D${lastRow}` } },
      { Métrica: "Despesas", Valor: { f: `Transações!D${lastRow + 1}` } },
      { Métrica: "Saldo", Valor: { f: `Transações!D${lastRow + 2}` } },
    ];

    const summarySheet = XLSX.utils.json_to_sheet(summaryData);
    XLSX.utils.book_append_sheet(workbook, summarySheet, "Resumo");

    return XLSX.write(workbook, { type: "buffer", bookType: "xlsx" });
  }

  getDashboardDateFilter(filter: "today" | "week" | "month" | "year" | "custom"): { startDate: Date; endDate: Date } {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const endDate = new Date(today);
    endDate.setHours(23, 59, 59, 999);

    let startDate = new Date(today);

    switch (filter) {
      case "today":
        break;

      case "week":
        startDate.setDate(today.getDate() - today.getDay());
        break;

      case "month":
        startDate.setDate(1);
        break;

      case "year":
        startDate.setMonth(0, 1);
        break;

      case "custom":
        break;
    }

    return { startDate, endDate };
  }
}

export const advancedReportsService = new AdvancedReportsService();
