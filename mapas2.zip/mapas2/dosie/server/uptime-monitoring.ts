import { Router } from "express";

const router = Router();

interface UptimeCheck {
  id: string;
  url: string;
  interval: number;
  status: 'up' | 'down';
  lastCheck: Date;
  uptime: number;
  responseTime: number;
}

class UptimeMonitor {
  private checks: Map<string, UptimeCheck> = new Map();
  private intervals: Map<string, NodeJS.Timeout> = new Map();
  private history: Map<string, { timestamp: Date; status: 'up' | 'down'; responseTime: number }[]> = new Map();

  async checkEndpoint(url: string): Promise<{ status: 'up' | 'down'; responseTime: number }> {
    const startTime = Date.now();
    try {
      const response = await fetch(url, {
        method: 'GET',
        signal: AbortSignal.timeout(10000)
      });
      
      const responseTime = Date.now() - startTime;
      return {
        status: response.ok ? 'up' : 'down',
        responseTime
      };
    } catch (error) {
      return {
        status: 'down',
        responseTime: Date.now() - startTime
      };
    }
  }

  startMonitoring(id: string, url: string, intervalMs: number = 60000) {
    if (this.intervals.has(id)) {
      this.stopMonitoring(id);
    }

    const check: UptimeCheck = {
      id,
      url,
      interval: intervalMs,
      status: 'up',
      lastCheck: new Date(),
      uptime: 100,
      responseTime: 0
    };

    this.checks.set(id, check);
    this.history.set(id, []);

    const interval = setInterval(async () => {
      const result = await this.checkEndpoint(url);
      check.status = result.status;
      check.lastCheck = new Date();
      check.responseTime = result.responseTime;

      const history = this.history.get(id) || [];
      history.push({
        timestamp: new Date(),
        status: result.status,
        responseTime: result.responseTime
      });

      if (history.length > 1000) {
        history.shift();
      }

      const upChecks = history.filter(h => h.status === 'up').length;
      check.uptime = (upChecks / history.length) * 100;

      this.checks.set(id, check);
      this.history.set(id, history);

      if (result.status === 'down') {
        console.error(`[Uptime Monitor] ${url} is DOWN! Response time: ${result.responseTime}ms`);
      }
    }, intervalMs);

    this.intervals.set(id, interval);
  }

  stopMonitoring(id: string) {
    const interval = this.intervals.get(id);
    if (interval) {
      clearInterval(interval);
      this.intervals.delete(id);
    }
  }

  getCheck(id: string): UptimeCheck | undefined {
    return this.checks.get(id);
  }

  getAllChecks(): UptimeCheck[] {
    return Array.from(this.checks.values());
  }

  getHistory(id: string, limit: number = 100) {
    const history = this.history.get(id) || [];
    return history.slice(-limit);
  }
}

const uptimeMonitor = new UptimeMonitor();

uptimeMonitor.startMonitoring('main-app', process.env.APP_URL || 'http://localhost:5000/api/health', 30000);

function requireAuth(req: any, res: any, next: any) {
  if (!req.user) {
    return res.status(401).json({ message: "Unauthorized" });
  }
  next();
}

router.get("/uptime", (req, res) => {
  const checks = uptimeMonitor.getAllChecks();
  res.json(checks);
});

router.get("/uptime/:id", (req, res) => {
  const check = uptimeMonitor.getCheck(req.params.id);
  if (!check) {
    return res.status(404).json({ message: "Check not found" });
  }
  res.json(check);
});

router.get("/uptime/:id/history", (req, res) => {
  const limit = parseInt(req.query.limit as string) || 100;
  const history = uptimeMonitor.getHistory(req.params.id, limit);
  res.json(history);
});

router.post("/uptime", requireAuth, async (req, res) => {
  try {
    const { id, url, interval } = req.body;

    if (!id || !url) {
      return res.status(400).json({ message: "id and url are required" });
    }

    uptimeMonitor.startMonitoring(id, url, interval || 60000);

    res.json({ message: "Uptime monitoring started", id });
  } catch (error) {
    console.error("Failed to start uptime monitoring:", error);
    res.status(500).json({ message: "Failed to start uptime monitoring" });
  }
});

router.delete("/uptime/:id", requireAuth, (req, res) => {
  uptimeMonitor.stopMonitoring(req.params.id);
  res.json({ message: "Uptime monitoring stopped" });
});

export default router;
export { uptimeMonitor };
