import { db } from "./db";
import { auditLogs } from "@shared/schema";
import { Router } from "express";
import { eq, and, desc } from "drizzle-orm";

const router = Router();

function requireAuth(req: any, res: any, next: any) {
  if (!req.user) {
    return res.status(401).json({ message: "Unauthorized" });
  }
  next();
}

export async function logAuditTrail(params: {
  organizationId?: string;
  userId?: string;
  action: string;
  entityType?: string;
  entityId?: string;
  oldValues?: any;
  newValues?: any;
  ipAddress?: string;
  userAgent?: string;
  metadata?: any;
}) {
  try {
    await db.insert(auditLogs).values({
      organizationId: params.organizationId || null,
      userId: params.userId || null,
      action: params.action,
      entityType: params.entityType || null,
      entityId: params.entityId || null,
      oldValues: params.oldValues ? JSON.stringify(params.oldValues) : null,
      newValues: params.newValues ? JSON.stringify(params.newValues) : null,
      ipAddress: params.ipAddress || null,
      userAgent: params.userAgent || null,
      metadata: params.metadata ? JSON.stringify(params.metadata) : null
    });
  } catch (error) {
    console.error("Failed to log audit trail:", error);
  }
}

router.get("/audit-logs", requireAuth, async (req, res) => {
  try {
    const organizationId = req.user!.organizationId;
    const limit = parseInt(req.query.limit as string) || 100;
    const offset = parseInt(req.query.offset as string) || 0;
    const action = req.query.action as string;
    const entityType = req.query.entityType as string;
    const userId = req.query.userId as string;

    const conditions = [eq(auditLogs.organizationId, organizationId)];

    if (action) {
      conditions.push(eq(auditLogs.action, action));
    }
    if (entityType) {
      conditions.push(eq(auditLogs.entityType, entityType));
    }
    if (userId) {
      conditions.push(eq(auditLogs.userId, userId));
    }

    const whereConditions = and(...conditions);

    const logs = await db.query.auditLogs.findMany({
      where: whereConditions,
      orderBy: [desc(auditLogs.createdAt)],
      limit,
      offset,
      with: {
        user: {
          columns: {
            id: true,
            name: true,
            email: true
          }
        }
      }
    });

    const total = await db.select({ count: auditLogs.id })
      .from(auditLogs)
      .where(whereConditions);

    const formattedLogs = logs.map(log => ({
      ...log,
      oldValues: log.oldValues ? JSON.parse(log.oldValues) : null,
      newValues: log.newValues ? JSON.parse(log.newValues) : null,
      metadata: log.metadata ? JSON.parse(log.metadata) : null
    }));

    res.json({
      data: formattedLogs,
      total: total.length,
      limit,
      offset
    });
  } catch (error) {
    console.error("Failed to get audit logs:", error);
    res.status(500).json({ message: "Failed to get audit logs" });
  }
});

router.get("/audit-logs/:id", requireAuth, async (req, res) => {
  try {
    const organizationId = req.user!.organizationId;
    const logId = req.params.id;

    if (!organizationId) {
      return res.status(400).json({ message: "Organization ID required" });
    }

    const log = await db.query.auditLogs.findFirst({
      where: and(
        eq(auditLogs.id, logId),
        eq(auditLogs.organizationId, organizationId)
      ),
      with: {
        user: {
          columns: {
            id: true,
            name: true,
            email: true
          }
        }
      }
    });

    if (!log) {
      return res.status(404).json({ message: "Audit log not found" });
    }

    res.json({
      ...log,
      oldValues: log.oldValues ? JSON.parse(log.oldValues) : null,
      newValues: log.newValues ? JSON.parse(log.newValues) : null,
      metadata: log.metadata ? JSON.parse(log.metadata) : null
    });
  } catch (error) {
    console.error("Failed to get audit log:", error);
    res.status(500).json({ message: "Failed to get audit log" });
  }
});

export default router;
