import PDFDocument from "pdfkit";
import { Readable } from "stream";

export async function generateDREPDF(data: any): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    try {
      const doc = new PDFDocument({ size: "A4", margin: 50 });
      const chunks: Buffer[] = [];

      doc.on("data", (chunk) => chunks.push(chunk));
      doc.on("end", () => resolve(Buffer.concat(chunks)));
      doc.on("error", reject);

      doc.fontSize(20).text("Demonstração de Resultados do Exercício (DRE)", {
        align: "center",
      });
      
      doc.moveDown();
      doc.fontSize(12).text(
        `Período: ${new Date(data.periodo.inicio).toLocaleDateString()} a ${new Date(data.periodo.fim).toLocaleDateString()}`,
        { align: "center" }
      );
      
      doc.moveDown(2);

      doc.fontSize(14).text("Receitas", { underline: true });
      doc.moveDown(0.5);
      doc.fontSize(11);
      
      data.receitas.porCategoria.forEach((cat: any) => {
        doc.text(`  ${cat.categoria}: R$ ${cat.total.toFixed(2)}`);
      });
      
      doc.moveDown();
      doc.fontSize(12).fillColor("#008000").text(`Total de Receitas: R$ ${data.receitas.total.toFixed(2)}`);
      doc.fillColor("#000000");

      doc.moveDown(2);

      doc.fontSize(14).text("Despesas", { underline: true });
      doc.moveDown(0.5);
      doc.fontSize(11);
      
      data.despesas.porCategoria.forEach((cat: any) => {
        doc.text(`  ${cat.categoria}: R$ ${cat.total.toFixed(2)}`);
      });
      
      doc.moveDown();
      doc.fontSize(12).fillColor("#FF0000").text(`Total de Despesas: R$ ${data.despesas.total.toFixed(2)}`);
      doc.fillColor("#000000");

      doc.moveDown(2);
      doc.fontSize(16);
      
      if (data.lucroLiquido >= 0) {
        doc.fillColor("#008000").text(`Lucro Líquido: R$ ${data.lucroLiquido.toFixed(2)}`);
      } else {
        doc.fillColor("#FF0000").text(`Prejuízo: R$ ${Math.abs(data.lucroLiquido).toFixed(2)}`);
      }
      
      doc.fillColor("#000000");
      doc.fontSize(12).text(`Margem de Lucro: ${data.margemLucro.toFixed(2)}%`);

      doc.moveDown(3);
      doc.fontSize(8).fillColor("#666666").text(
        `Gerado em: ${new Date().toLocaleString()}`,
        { align: "center" }
      );

      doc.end();
    } catch (error) {
      reject(error);
    }
  });
}

export async function generateCashFlowPDF(data: any): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    try {
      const doc = new PDFDocument({ size: "A4", margin: 50 });
      const chunks: Buffer[] = [];

      doc.on("data", (chunk) => chunks.push(chunk));
      doc.on("end", () => resolve(Buffer.concat(chunks)));
      doc.on("error", reject);

      doc.fontSize(20).text("Fluxo de Caixa", { align: "center" });
      
      doc.moveDown();
      doc.fontSize(12).text(
        `Período: ${new Date(data.periodo.inicio).toLocaleDateString()} a ${new Date(data.periodo.fim).toLocaleDateString()}`,
        { align: "center" }
      );
      
      doc.moveDown(2);

      doc.fontSize(12).text(`Saldo Inicial: R$ ${data.saldoInicial.toFixed(2)}`);
      doc.text(`Total Entradas: R$ ${data.totalEntradas.toFixed(2)}`);
      doc.text(`Total Saídas: R$ ${data.totalSaidas.toFixed(2)}`);
      doc.text(`Fluxo Líquido: R$ ${data.fluxoLiquidoTotal.toFixed(2)}`);
      doc.text(`Saldo Final: R$ ${data.saldoFinal.toFixed(2)}`);

      doc.moveDown(2);
      doc.fontSize(14).text("Fluxo Mensal", { underline: true });
      doc.moveDown();

      doc.fontSize(10);
      data.fluxoMensal.forEach((mes: any) => {
        doc.text(`${mes.mes}:`);
        doc.text(`  Entradas: R$ ${mes.entradas.toFixed(2)}`);
        doc.text(`  Saídas: R$ ${mes.saidas.toFixed(2)}`);
        doc.text(`  Fluxo Líquido: R$ ${mes.fluxoLiquido.toFixed(2)}`);
        doc.text(`  Saldo Acumulado: R$ ${mes.saldoAcumulado.toFixed(2)}`);
        doc.moveDown(0.5);
      });

      doc.moveDown(2);
      doc.fontSize(8).fillColor("#666666").text(
        `Gerado em: ${new Date().toLocaleString()}`,
        { align: "center" }
      );

      doc.end();
    } catch (error) {
      reject(error);
    }
  });
}

export async function generateStatementPDF(data: any): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    try {
      const doc = new PDFDocument({ size: "A4", margin: 50 });
      const chunks: Buffer[] = [];

      doc.on("data", (chunk) => chunks.push(chunk));
      doc.on("end", () => resolve(Buffer.concat(chunks)));
      doc.on("error", reject);

      doc.fontSize(20).text("Extrato Detalhado de Transações", {
        align: "center",
      });
      
      doc.moveDown();
      doc.fontSize(12).text(
        `Período: ${new Date(data.periodo.inicio).toLocaleDateString()} a ${new Date(data.periodo.fim).toLocaleDateString()}`,
        { align: "center" }
      );
      
      doc.moveDown(2);

      doc.fontSize(12).text(`Total de Transações: ${data.totalTransacoes}`);
      doc.text(`Total Entradas: R$ ${data.totalEntradas.toFixed(2)}`);
      doc.text(`Total Saídas: R$ ${data.totalSaidas.toFixed(2)}`);
      doc.text(`Saldo Líquido: R$ ${data.saldoLiquido.toFixed(2)}`);

      doc.moveDown(2);
      doc.fontSize(14).text("Transações", { underline: true });
      doc.moveDown();

      doc.fontSize(9);
      data.transacoes.forEach((trans: any, index: number) => {
        if (index > 0 && index % 25 === 0) {
          doc.addPage();
          doc.fontSize(9);
        }

        const tipo = trans.type === 'income' ? 'RECEITA' : 'DESPESA';
        const cor = trans.type === 'income' ? '#008000' : '#FF0000';
        const sinal = trans.type === 'income' ? '+' : '-';
        
        doc.fillColor('#000000');
        doc.text(`${new Date(trans.date).toLocaleDateString()} - ${trans.description}`, {
          continued: true,
        });
        doc.fillColor(cor).text(` ${sinal}R$ ${parseFloat(trans.amount).toFixed(2)}`, {
          align: 'right',
        });
        
        doc.fillColor('#666666').fontSize(8);
        if (trans.categoria) {
          doc.text(`  Categoria: ${trans.categoria}`, { indent: 10 });
        }
        if (trans.conta) {
          doc.text(`  Conta: ${trans.conta}`, { indent: 10 });
        }
        doc.fontSize(9).fillColor('#000000');
        doc.moveDown(0.5);
      });

      doc.moveDown(2);
      doc.fontSize(8).fillColor("#666666").text(
        `Gerado em: ${new Date().toLocaleString()}`,
        { align: "center" }
      );

      doc.end();
    } catch (error) {
      reject(error);
    }
  });
}

export async function generateInvoicePDF(invoice: any): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    try {
      const doc = new PDFDocument({ size: "A4", margin: 50 });
      const chunks: Buffer[] = [];

      doc.on("data", (chunk) => chunks.push(chunk));
      doc.on("end", () => resolve(Buffer.concat(chunks)));
      doc.on("error", reject);

      doc.fontSize(24).text("FATURA", { align: "center" });
      
      doc.moveDown();
      doc.fontSize(14).text(`#${invoice.invoiceNumber}`, { align: "center" });
      
      doc.moveDown(2);

      doc.fontSize(12).text(`Data de Emissão: ${new Date(invoice.issueDate).toLocaleDateString()}`);
      if (invoice.dueDate) {
        doc.text(`Vencimento: ${new Date(invoice.dueDate).toLocaleDateString()}`);
      }
      
      doc.moveDown();
      doc.text(`Status: ${invoice.status.toUpperCase()}`);

      doc.moveDown(2);
      doc.fontSize(14).text("Descrição", { underline: true });
      doc.moveDown(0.5);
      doc.fontSize(11).text(invoice.description || "Sem descrição");

      doc.moveDown(2);
      doc.fontSize(18).fillColor("#008000").text(
        `Valor: R$ ${parseFloat(invoice.amount).toFixed(2)}`,
        { align: "right" }
      );

      if (invoice.notes) {
        doc.moveDown(3);
        doc.fillColor("#000000");
        doc.fontSize(10).text("Observações:");
        doc.fontSize(9).text(invoice.notes);
      }

      doc.moveDown(4);
      doc.fontSize(8).fillColor("#666666").text(
        `Gerado em: ${new Date().toLocaleString()}`,
        { align: "center" }
      );

      doc.end();
    } catch (error) {
      reject(error);
    }
  });
}
