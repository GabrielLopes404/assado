import { Router } from "express";
import { db } from "./db";
import { termsAcceptance, users } from "@shared/schema";
import { eq, and, desc } from "drizzle-orm";

const router = Router();

const CURRENT_TERMS_VERSION = "1.0.0";
const CURRENT_PRIVACY_VERSION = "1.0.0";
const CURRENT_LGPD_VERSION = "1.0.0";

const termsContent = {
  version: CURRENT_TERMS_VERSION,
  updatedAt: "2025-01-01",
  sections: [
    {
      title: "1. Aceitação dos Termos",
      content: "Ao acessar e usar o LUCREI, você concorda com estes Termos de Uso."
    },
    {
      title: "2. Descrição do Serviço",
      content: "O LUCREI é uma plataforma de gestão financeira para pequenas e médias empresas."
    },
    {
      title: "3. Responsabilidades do Usuário",
      content: "Você é responsável por manter suas credenciais seguras e por todas as atividades em sua conta."
    },
    {
      title: "4. Privacidade e Dados",
      content: "Seus dados são protegidos conforme nossa Política de Privacidade e as leis LGPD."
    },
    {
      title: "5. Limitações e Garantias",
      content: "O serviço é fornecido 'como está'. Não garantimos disponibilidade 100% do tempo."
    }
  ]
};

const privacyContent = {
  version: CURRENT_PRIVACY_VERSION,
  updatedAt: "2025-01-01",
  sections: [
    {
      title: "1. Coleta de Dados",
      content: "Coletamos dados necessários para fornecer nossos serviços financeiros."
    },
    {
      title: "2. Uso dos Dados",
      content: "Seus dados são usados exclusivamente para operação da plataforma."
    },
    {
      title: "3. Compartilhamento",
      content: "Não compartilhamos seus dados com terceiros sem seu consentimento."
    },
    {
      title: "4. Segurança",
      content: "Implementamos medidas de segurança robustas incluindo criptografia e 2FA."
    },
    {
      title: "5. Seus Direitos",
      content: "Você tem direito a acessar, corrigir e deletar seus dados a qualquer momento."
    }
  ]
};

const lgpdContent = {
  version: CURRENT_LGPD_VERSION,
  updatedAt: "2025-01-01",
  sections: [
    {
      title: "1. Conformidade LGPD",
      content: "O LUCREI está em total conformidade com a Lei Geral de Proteção de Dados (LGPD)."
    },
    {
      title: "2. Base Legal",
      content: "Processamos dados com base em contrato e consentimento explícito."
    },
    {
      title: "3. Direitos do Titular",
      content: "Você tem direito à portabilidade, correção, exclusão e oposição ao tratamento de dados."
    },
    {
      title: "4. Encarregado (DPO)",
      content: "Nosso DPO está disponível em dpo@lucrei.com para questões sobre privacidade."
    },
    {
      title: "5. Tempo de Retenção",
      content: "Dados são mantidos pelo tempo necessário ou conforme exigido por lei."
    }
  ]
};

function requireAuth(req: any, res: any, next: any) {
  if (!req.user) {
    return res.status(401).json({ message: "Unauthorized" });
  }
  next();
}

router.get("/terms/current", (req, res) => {
  res.json({
    terms: termsContent,
    privacy: privacyContent,
    lgpd: lgpdContent,
    currentVersions: {
      terms: CURRENT_TERMS_VERSION,
      privacy: CURRENT_PRIVACY_VERSION,
      lgpd: CURRENT_LGPD_VERSION
    }
  });
});

router.post("/terms/accept", requireAuth, async (req, res) => {
  try {
    const userId = req.user!.id;
    const { type } = req.body;

    if (!["terms", "privacy", "lgpd"].includes(type)) {
      return res.status(400).json({ message: "Invalid type. Must be: terms, privacy, or lgpd" });
    }

    const version = type === "terms" ? CURRENT_TERMS_VERSION 
                  : type === "privacy" ? CURRENT_PRIVACY_VERSION 
                  : CURRENT_LGPD_VERSION;

    const existingAcceptance = await db.query.termsAcceptance.findFirst({
      where: and(
        eq(termsAcceptance.userId, userId),
        eq(termsAcceptance.termsType, type),
        eq(termsAcceptance.termsVersion, version)
      )
    });

    if (existingAcceptance) {
      return res.json({ 
        message: "Terms already accepted",
        acceptance: existingAcceptance 
      });
    }

    const [acceptance] = await db.insert(termsAcceptance).values({
      userId,
      termsType: type,
      termsVersion: version,
      ipAddress: req.ip || req.socket.remoteAddress || '',
      userAgent: req.headers['user-agent'] || null
    }).returning();

    res.json({ 
      message: "Terms accepted successfully",
      acceptance 
    });
  } catch (error) {
    console.error("Failed to accept terms:", error);
    res.status(500).json({ message: "Failed to accept terms" });
  }
});

router.get("/terms/acceptance-history", requireAuth, async (req, res) => {
  try {
    const userId = req.user!.id;

    const history = await db.query.termsAcceptance.findMany({
      where: eq(termsAcceptance.userId, userId),
      orderBy: [desc(termsAcceptance.acceptedAt)]
    });

    const currentStatus = {
      terms: history.find(h => h.termsType === "terms" && h.termsVersion === CURRENT_TERMS_VERSION),
      privacy: history.find(h => h.termsType === "privacy" && h.termsVersion === CURRENT_PRIVACY_VERSION),
      lgpd: history.find(h => h.termsType === "lgpd" && h.termsVersion === CURRENT_LGPD_VERSION)
    };

    res.json({
      current: currentStatus,
      history,
      needsAcceptance: {
        terms: !currentStatus.terms,
        privacy: !currentStatus.privacy,
        lgpd: !currentStatus.lgpd
      }
    });
  } catch (error) {
    console.error("Failed to get acceptance history:", error);
    res.status(500).json({ message: "Failed to get acceptance history" });
  }
});

router.get("/terms/status", requireAuth, async (req, res) => {
  try {
    const userId = req.user!.id;

    const acceptances = await db.query.termsAcceptance.findMany({
      where: eq(termsAcceptance.userId, userId),
      orderBy: [desc(termsAcceptance.acceptedAt)],
      limit: 10
    });

    const hasAcceptedTerms = acceptances.some(
      a => a.termsType === "terms" && a.termsVersion === CURRENT_TERMS_VERSION
    );
    const hasAcceptedPrivacy = acceptances.some(
      a => a.termsType === "privacy" && a.termsVersion === CURRENT_PRIVACY_VERSION
    );
    const hasAcceptedLGPD = acceptances.some(
      a => a.termsType === "lgpd" && a.termsVersion === CURRENT_LGPD_VERSION
    );

    res.json({
      accepted: {
        terms: hasAcceptedTerms,
        privacy: hasAcceptedPrivacy,
        lgpd: hasAcceptedLGPD,
        all: hasAcceptedTerms && hasAcceptedPrivacy && hasAcceptedLGPD
      },
      currentVersions: {
        terms: CURRENT_TERMS_VERSION,
        privacy: CURRENT_PRIVACY_VERSION,
        lgpd: CURRENT_LGPD_VERSION
      },
      recentAcceptances: acceptances
    });
  } catch (error) {
    console.error("Failed to get terms status:", error);
    res.status(500).json({ message: "Failed to get terms status" });
  }
});

export default router;
