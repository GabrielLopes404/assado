import crypto from "crypto";
import { Request, Response, NextFunction } from "express";
import { storage } from "./storage";
import { sendEmail, generateEmailVerificationEmail, generateWelcomeEmail } from "./email";

export function generateVerificationToken(): string {
  return crypto.randomBytes(32).toString("hex");
}

export async function sendVerificationEmail(userId: string, email: string, name: string, baseUrl: string): Promise<boolean> {
  const token = generateVerificationToken();
  const tokenExpiry = new Date(Date.now() + 24 * 60 * 60 * 1000);
  
  await storage.updateUser(userId, {
    verificationToken: token,
    resetTokenExpiry: tokenExpiry,
  });

  const verifyLink = `${baseUrl}/verify-email?token=${token}`;
  const html = generateEmailVerificationEmail(verifyLink, name);

  return await sendEmail({
    to: email,
    subject: "Verificar Email - LUCREI",
    html,
    text: `Olá ${name}, por favor verifique seu email clicando neste link: ${verifyLink}`,
  });
}

export async function verifyEmailToken(token: string): Promise<{ success: boolean; message: string; userId?: string }> {
  const user = await storage.getUserByVerificationToken(token);
  
  if (!user) {
    return { success: false, message: "Token inválido" };
  }

  if (user.resetTokenExpiry && new Date() > new Date(user.resetTokenExpiry)) {
    return { success: false, message: "Token expirado" };
  }

  await storage.updateUser(user.id, {
    emailVerified: true,
    verificationToken: null,
    resetTokenExpiry: null,
  });

  const html = generateWelcomeEmail(user.name || user.username);
  await sendEmail({
    to: user.email,
    subject: "Bem-vindo ao LUCREI!",
    html,
    text: `Bem-vindo ao LUCREI, ${user.name}! Seu email foi verificado com sucesso.`,
  });

  return { success: true, message: "Email verificado com sucesso", userId: user.id };
}

export function requireEmailVerification(req: Request, res: Response, next: NextFunction) {
  if (!req.isAuthenticated()) {
    return res.status(401).json({ message: "Não autenticado" });
  }

  if (!req.user!.emailVerified) {
    return res.status(403).json({ 
      message: "Email não verificado. Por favor, verifique seu email antes de continuar.",
      emailVerificationRequired: true 
    });
  }

  next();
}
