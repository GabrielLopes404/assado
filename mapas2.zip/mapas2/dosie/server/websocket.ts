import { Server as SocketServer } from "socket.io";
import { Server as HttpServer } from "http";
import type { User } from "@shared/schema";

interface AuthenticatedSocket {
  userId: string;
  organizationId: string;
  user: User;
}

export class WebSocketService {
  private io: SocketServer | null = null;
  private userSockets: Map<string, Set<string>> = new Map();

  initialize(server: HttpServer) {
    this.io = new SocketServer(server, {
      cors: {
        origin: process.env.NODE_ENV === "production" 
          ? process.env.ALLOWED_ORIGINS?.split(',') || []
          : true,
        credentials: true,
      },
      path: "/socket.io",
    });

    this.io.on("connection", (socket) => {
      console.log(`Socket connected: ${socket.id}`);

      socket.on("authenticate", (data: { userId: string; organizationId: string }) => {
        if (!data.userId || !data.organizationId) {
          socket.disconnect();
          return;
        }

        (socket as any).userId = data.userId;
        (socket as any).organizationId = data.organizationId;

        socket.join(`org:${data.organizationId}`);
        socket.join(`user:${data.userId}`);

        if (!this.userSockets.has(data.userId)) {
          this.userSockets.set(data.userId, new Set());
        }
        this.userSockets.get(data.userId)!.add(socket.id);

        console.log(`User ${data.userId} authenticated on socket ${socket.id}`);
        socket.emit("authenticated", { success: true });
      });

      socket.on("disconnect", () => {
        const userId = (socket as any).userId;
        if (userId && this.userSockets.has(userId)) {
          this.userSockets.get(userId)!.delete(socket.id);
          if (this.userSockets.get(userId)!.size === 0) {
            this.userSockets.delete(userId);
          }
        }
        console.log(`Socket disconnected: ${socket.id}`);
      });
    });

    console.log("✅ WebSocket server initialized");
  }

  notifyOrganization(organizationId: string, event: string, data: any) {
    if (this.io) {
      this.io.to(`org:${organizationId}`).emit(event, data);
    }
  }

  notifyUser(userId: string, event: string, data: any) {
    if (this.io) {
      this.io.to(`user:${userId}`).emit(event, data);
    }
  }

  broadcastToAll(event: string, data: any) {
    if (this.io) {
      this.io.emit(event, data);
    }
  }

  getConnectedUsers(): string[] {
    return Array.from(this.userSockets.keys());
  }

  isUserConnected(userId: string): boolean {
    return this.userSockets.has(userId) && this.userSockets.get(userId)!.size > 0;
  }
}

export const wsService = new WebSocketService();
