import { Router } from "express";
import { db } from "./db";
import { organizations } from "@shared/schema";
import { eq } from "drizzle-orm";

const router = Router();

function requireAuth(req: any, res: any, next: any) {
  if (!req.user) {
    return res.status(401).json({ message: "Unauthorized" });
  }
  next();
}

function isOwner(req: any, res: any, next: any) {
  if (!req.user || req.user.role !== 'OWNER') {
    return res.status(403).json({ message: "Forbidden: Owner access required" });
  }
  next();
}

interface WhiteLabelConfig {
  primaryColor?: string;
  secondaryColor?: string;
  accentColor?: string;
  logo?: string;
  favicon?: string;
  companyName?: string;
  customDomain?: string;
  emailFromName?: string;
  emailFromAddress?: string;
  hideReplit?: boolean;
  customCSS?: string;
}

const whiteLabelConfigs = new Map<string, WhiteLabelConfig>();

router.get("/white-label/config", requireAuth, (req, res) => {
  const organizationId = req.user!.organizationId;
  const config = whiteLabelConfigs.get(organizationId) || {};
  
  res.json(config);
});

router.put("/white-label/config", requireAuth, isOwner, async (req, res) => {
  try {
    const organizationId = req.user!.organizationId;
    const config: WhiteLabelConfig = req.body;

    const validFields = [
      'primaryColor',
      'secondaryColor',
      'accentColor',
      'logo',
      'favicon',
      'companyName',
      'customDomain',
      'emailFromName',
      'emailFromAddress',
      'hideReplit',
      'customCSS'
    ];

    const filteredConfig: any = {};
    for (const field of validFields) {
      if (config[field as keyof WhiteLabelConfig] !== undefined) {
        filteredConfig[field] = config[field as keyof WhiteLabelConfig];
      }
    }

    whiteLabelConfigs.set(organizationId, filteredConfig);

    if (filteredConfig.companyName || filteredConfig.logo) {
      await db.update(organizations)
        .set({
          name: filteredConfig.companyName || undefined,
          logo: filteredConfig.logo || undefined
        })
        .where(eq(organizations.id, organizationId));
    }

    res.json({
      message: "White-label configuration updated successfully",
      config: filteredConfig
    });
  } catch (error) {
    console.error("Failed to update white-label config:", error);
    res.status(500).json({ message: "Failed to update white-label configuration" });
  }
});

router.delete("/white-label/config", requireAuth, isOwner, (req, res) => {
  const organizationId = req.user!.organizationId;
  whiteLabelConfigs.delete(organizationId);
  
  res.json({ message: "White-label configuration reset successfully" });
});

router.get("/white-label/preview", requireAuth, (req, res) => {
  const organizationId = req.user!.organizationId;
  const config = whiteLabelConfigs.get(organizationId) || {};
  
  const preview = `
    <!DOCTYPE html>
    <html>
    <head>
      <title>${config.companyName || 'LUCREI'}</title>
      <link rel="icon" href="${config.favicon || '/favicon.ico'}">
      <style>
        :root {
          --primary-color: ${config.primaryColor || '#6366f1'};
          --secondary-color: ${config.secondaryColor || '#8b5cf6'};
          --accent-color: ${config.accentColor || '#ec4899'};
        }
        ${config.customCSS || ''}
        
        body {
          font-family: system-ui, -apple-system, sans-serif;
          margin: 0;
          padding: 20px;
          background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
          min-height: 100vh;
          color: white;
        }
        .container {
          max-width: 800px;
          margin: 0 auto;
          text-align: center;
        }
        .logo {
          width: 200px;
          margin-bottom: 20px;
        }
        h1 {
          font-size: 3rem;
          margin-bottom: 10px;
        }
        p {
          font-size: 1.2rem;
          opacity: 0.9;
        }
        .button {
          background: var(--accent-color);
          color: white;
          padding: 12px 24px;
          border-radius: 8px;
          text-decoration: none;
          display: inline-block;
          margin-top: 20px;
          font-weight: 600;
        }
      </style>
    </head>
    <body>
      <div class="container">
        ${config.logo ? `<img src="${config.logo}" alt="Logo" class="logo">` : ''}
        <h1>${config.companyName || 'LUCREI'}</h1>
        <p>Seu sistema de gestão financeira personalizado</p>
        <a href="/" class="button">Acessar Plataforma</a>
      </div>
    </body>
    </html>
  `;
  
  res.setHeader('Content-Type', 'text/html');
  res.send(preview);
});

export default router;
export { whiteLabelConfigs };
