import { Router } from "express";
import { db } from "./db";
import { loginDevices, loginHistory } from "@shared/schema";
import { eq, desc } from "drizzle-orm";
import crypto from "crypto";

const router = Router();

function requireAuth(req: any, res: any, next: any) {
  if (!req.user) {
    return res.status(401).json({ message: "Unauthorized" });
  }
  next();
}

function generateDeviceFingerprint(userAgent: string, ipAddress: string): string {
  const hash = crypto.createHash('sha256');
  hash.update(`${userAgent}${ipAddress}`);
  return hash.digest('hex');
}

function parseUserAgent(userAgent: string) {
  const browserMatch = userAgent.match(/(Chrome|Firefox|Safari|Edge|Opera)\/?([\d.]+)?/);
  const osMatch = userAgent.match(/(Windows|Mac OS|Linux|Android|iOS)/);
  const deviceMatch = userAgent.match(/(Mobile|Tablet)/);

  return {
    browser: browserMatch ? browserMatch[1] : 'Unknown',
    os: osMatch ? osMatch[1] : 'Unknown',
    deviceType: deviceMatch ? deviceMatch[1] : 'Desktop'
  };
}

export async function trackLoginAttempt(params: {
  userId?: string;
  email: string;
  ipAddress: string;
  userAgent: string;
  success: boolean;
  failureReason?: string;
  twoFactorUsed?: boolean;
}) {
  try {
    const deviceFingerprint = generateDeviceFingerprint(params.userAgent, params.ipAddress);
    const { browser, os } = parseUserAgent(params.userAgent);

    await db.insert(loginHistory).values({
      userId: params.userId || null,
      email: params.email,
      ipAddress: params.ipAddress,
      userAgent: params.userAgent,
      deviceFingerprint,
      browser,
      os,
      success: params.success,
      failureReason: params.failureReason,
      twoFactorUsed: params.twoFactorUsed || false
    });

    if (params.success && params.userId) {
      const { browser, os, deviceType } = parseUserAgent(params.userAgent);
      
      const existingDevice = await db.query.loginDevices.findFirst({
        where: eq(loginDevices.deviceFingerprint, deviceFingerprint)
      });

      if (existingDevice) {
        await db.update(loginDevices)
          .set({
            lastUsedAt: new Date(),
            ipAddress: params.ipAddress
          })
          .where(eq(loginDevices.id, existingDevice.id));
      } else {
        await db.insert(loginDevices).values({
          userId: params.userId,
          deviceFingerprint,
          userAgent: params.userAgent,
          ipAddress: params.ipAddress,
          browser,
          os,
          deviceType,
          isTrusted: false
        });
      }
    }
  } catch (error) {
    console.error("Failed to track login attempt:", error);
  }
}

router.get("/devices", requireAuth, async (req, res) => {
  try {
    const userId = req.user!.id;

    const devices = await db.query.loginDevices.findMany({
      where: eq(loginDevices.userId, userId),
      orderBy: [desc(loginDevices.lastUsedAt)]
    });

    res.json(devices);
  } catch (error) {
    console.error("Failed to get devices:", error);
    res.status(500).json({ message: "Failed to get devices" });
  }
});

router.post("/devices/:id/trust", requireAuth, async (req, res) => {
  try {
    const userId = req.user!.id;
    const deviceId = req.params.id;

    const device = await db.query.loginDevices.findFirst({
      where: eq(loginDevices.id, deviceId)
    });

    if (!device || device.userId !== userId) {
      return res.status(404).json({ message: "Device not found" });
    }

    await db.update(loginDevices)
      .set({ isTrusted: true })
      .where(eq(loginDevices.id, deviceId));

    res.json({ message: "Device marked as trusted" });
  } catch (error) {
    console.error("Failed to trust device:", error);
    res.status(500).json({ message: "Failed to trust device" });
  }
});

router.delete("/devices/:id", requireAuth, async (req, res) => {
  try {
    const userId = req.user!.id;
    const deviceId = req.params.id;

    const device = await db.query.loginDevices.findFirst({
      where: eq(loginDevices.id, deviceId)
    });

    if (!device || device.userId !== userId) {
      return res.status(404).json({ message: "Device not found" });
    }

    await db.delete(loginDevices)
      .where(eq(loginDevices.id, deviceId));

    res.json({ message: "Device removed" });
  } catch (error) {
    console.error("Failed to remove device:", error);
    res.status(500).json({ message: "Failed to remove device" });
  }
});

router.get("/login-history", requireAuth, async (req, res) => {
  try {
    const userId = req.user!.id;
    const limit = parseInt(req.query.limit as string) || 50;
    const offset = parseInt(req.query.offset as string) || 0;

    const history = await db.query.loginHistory.findMany({
      where: eq(loginHistory.userId, userId),
      orderBy: [desc(loginHistory.createdAt)],
      limit,
      offset
    });

    const total = await db.select({ count: loginHistory.id })
      .from(loginHistory)
      .where(eq(loginHistory.userId, userId));

    res.json({
      data: history,
      total: total.length,
      limit,
      offset
    });
  } catch (error) {
    console.error("Failed to get login history:", error);
    res.status(500).json({ message: "Failed to get login history" });
  }
});

export default router;
