import { Router } from "express";
import { exec } from "child_process";
import { promisify } from "util";

const execAsync = promisify(exec);
const router = Router();

function requireAuth(req: any, res: any, next: any) {
  if (!req.user) {
    return res.status(401).json({ message: "Unauthorized" });
  }
  next();
}

function isOwner(req: any, res: any, next: any) {
  if (!req.user || req.user.role !== 'OWNER') {
    return res.status(403).json({ message: "Forbidden: Owner access required" });
  }
  next();
}

router.get("/testing/coverage", requireAuth, isOwner, async (req, res) => {
  try {
    const { stdout } = await execAsync("npm run test:coverage 2>&1 || echo 'Tests not configured'");
    
    const coverageMatch = stdout.match(/All files\s+\|\s+([\d.]+)\s+\|\s+([\d.]+)\s+\|\s+([\d.]+)\s+\|\s+([\d.]+)/);
    
    if (coverageMatch) {
      const [, statements, branches, functions, lines] = coverageMatch;
      res.json({
        total: {
          statements: { pct: parseFloat(statements) },
          branches: { pct: parseFloat(branches) },
          functions: { pct: parseFloat(functions) },
          lines: { pct: parseFloat(lines) }
        },
        timestamp: new Date().toISOString(),
        rawOutput: stdout.substring(0, 1000)
      });
    } else {
      res.json({
        message: "Coverage data not available. Run 'npm run test:coverage' to generate coverage reports.",
        timestamp: new Date().toISOString()
      });
    }
  } catch (error) {
    console.error("Failed to get coverage:", error);
    res.status(500).json({ 
      message: "Failed to get test coverage. Ensure Vitest is properly configured.",
      error: error instanceof Error ? error.message : 'Unknown error'
    });
  }
});

router.post("/testing/run", requireAuth, isOwner, async (req, res) => {
  try {
    const { type } = req.body;
    
    let command = "npm run test";
    if (type === "unit") command = "npm run test -- --run";
    else if (type === "integration") command = "npm run test -- --run";
    else if (type === "e2e") command = "npm run test:e2e";

    const { stdout, stderr } = await execAsync(`${command} 2>&1 || echo 'Tests executed with errors'`);

    const passedMatch = stdout.match(/(\d+) passed/);
    const failedMatch = stdout.match(/(\d+) failed/);
    const totalMatch = stdout.match(/Tests\s+(\d+)\s+passed/);

    res.json({
      type: type || 'all',
      results: {
        passed: passedMatch ? parseInt(passedMatch[1]) : 0,
        failed: failedMatch ? parseInt(failedMatch[1]) : 0,
        total: totalMatch ? parseInt(totalMatch[1]) : 0
      },
      timestamp: new Date().toISOString(),
      output: stdout.substring(0, 1000)
    });
  } catch (error) {
    console.error("Failed to run tests:", error);
    res.status(500).json({ 
      message: "Failed to run tests",
      error: error instanceof Error ? error.message : 'Unknown error'
    });
  }
});

export default router;
