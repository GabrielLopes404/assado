import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useParams } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Download, FileText, Clock, CheckCircle2, CreditCard } from "lucide-react";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Alert, AlertDescription } from "@/components/ui/alert";

interface Invoice {
  id: string;
  invoiceNumber: string;
  amount: number;
  status: string;
  dueDate: string;
  paidDate: string | null;
  createdAt: string;
  items: any[];
}

interface Customer {
  id: string;
  name: string;
  email: string;
  phone: string | null;
}

export default function CustomerPortalPage() {
  const { customerId } = useParams<{ customerId: string }>();
  const [token, setToken] = useState<string | null>(null);

  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const tokenParam = urlParams.get("token");
    setToken(tokenParam);
  }, []);

  const { data: customer, isLoading: customerLoading } = useQuery<Customer>({
    queryKey: [`/api/portal/${customerId}/customer`],
    enabled: !!customerId && !!token,
    meta: {
      headers: {
        "X-Portal-Token": token || "",
      },
    },
  });

  const { data: invoices, isLoading: invoicesLoading } = useQuery<Invoice[]>({
    queryKey: [`/api/portal/${customerId}/invoices`],
    enabled: !!customerId && !!token,
    meta: {
      headers: {
        "X-Portal-Token": token || "",
      },
    },
  });

  const handleDownloadPDF = async (invoiceId: string) => {
    const response = await fetch(`/api/portal/${customerId}/invoices/${invoiceId}/pdf`, {
      headers: {
        "X-Portal-Token": token || "",
      },
    });
    const blob = await response.blob();
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `invoice-${invoiceId}.pdf`;
    a.click();
  };

  const statusColors: Record<string, string> = {
    draft: "bg-gray-500",
    sent: "bg-blue-500",
    paid: "bg-green-500",
    overdue: "bg-red-500",
    cancelled: "bg-gray-400",
  };

  const statusLabels: Record<string, string> = {
    draft: "Rascunho",
    sent: "Enviada",
    paid: "Paga",
    overdue: "Atrasada",
    cancelled: "Cancelada",
  };

  if (!token) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-primary/5 to-secondary/5 flex items-center justify-center p-4">
        <Alert variant="destructive" className="max-w-md">
          <AlertDescription>
            Token de acesso inválido ou ausente. Por favor, use o link enviado por email.
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  if (customerLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-primary/5 to-secondary/5 flex items-center justify-center">
        <p className="text-lg text-muted-foreground">Carregando...</p>
      </div>
    );
  }

  if (!customer) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-primary/5 to-secondary/5 flex items-center justify-center p-4">
        <Alert variant="destructive" className="max-w-md">
          <AlertDescription>
            Cliente não encontrado ou acesso negado.
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 to-secondary/5">
      <div className="container mx-auto p-6 max-w-6xl">
        <div className="mb-8">
          <div className="bg-white rounded-lg shadow-sm p-8">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-bold mb-2">{customer.name}</h1>
                <p className="text-muted-foreground">{customer.email}</p>
                {customer.phone && (
                  <p className="text-muted-foreground">{customer.phone}</p>
                )}
              </div>
              <FileText className="h-12 w-12 text-primary" />
            </div>
          </div>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5" />
              Suas Faturas
            </CardTitle>
          </CardHeader>
          <CardContent>
            {invoicesLoading ? (
              <p className="text-center py-8 text-muted-foreground">Carregando faturas...</p>
            ) : invoices && invoices.length > 0 ? (
              <div className="space-y-4">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Número</TableHead>
                      <TableHead>Data de Emissão</TableHead>
                      <TableHead>Vencimento</TableHead>
                      <TableHead>Valor</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Ações</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {invoices.map((invoice) => (
                      <TableRow key={invoice.id}>
                        <TableCell className="font-medium">
                          {invoice.invoiceNumber}
                        </TableCell>
                        <TableCell>
                          {format(new Date(invoice.createdAt), "dd/MM/yyyy", { locale: ptBR })}
                        </TableCell>
                        <TableCell>
                          {format(new Date(invoice.dueDate), "dd/MM/yyyy", { locale: ptBR })}
                        </TableCell>
                        <TableCell className="font-semibold">
                          R$ {invoice.amount.toFixed(2)}
                        </TableCell>
                        <TableCell>
                          <Badge
                            className={`${statusColors[invoice.status]} text-white`}
                          >
                            {statusLabels[invoice.status]}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-2">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleDownloadPDF(invoice.id)}
                            >
                              <Download className="mr-2 h-3 w-3" />
                              PDF
                            </Button>
                            {invoice.status === "sent" && (
                              <Button size="sm">
                                Pagar Agora
                              </Button>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>

                <div className="mt-8 p-6 bg-muted rounded-lg">
                  <h3 className="font-semibold mb-2 flex items-center gap-2">
                    <CheckCircle2 className="h-5 w-5 text-green-600" />
                    Resumo
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
                    <div>
                      <p className="text-sm text-muted-foreground">Total de Faturas</p>
                      <p className="text-2xl font-bold">{invoices.length}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Faturas Pagas</p>
                      <p className="text-2xl font-bold text-green-600">
                        {invoices.filter((i) => i.status === "paid").length}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Faturas Pendentes</p>
                      <p className="text-2xl font-bold text-orange-600">
                        {invoices.filter((i) => i.status === "sent" || i.status === "overdue").length}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center py-12">
                <FileText className="h-12 w-12 text-muted-foreground mb-4" />
                <h3 className="text-lg font-semibold mb-2">Nenhuma fatura encontrada</h3>
                <p className="text-sm text-muted-foreground text-center max-w-md">
                  Você não possui faturas no momento.
                </p>
              </div>
            )}
          </CardContent>
        </Card>

        <div className="mt-6 text-center text-sm text-muted-foreground">
          <p>
            Precisa de ajuda? Entre em contato conosco.
          </p>
        </div>
      </div>
    </div>
  );
}
